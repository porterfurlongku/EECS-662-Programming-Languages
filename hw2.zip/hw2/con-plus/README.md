# Con+

This is the starter code for the Con+ language. See the assignment [instructions](https://sankhs.com/eecs662/assignments/2-moreprim-cond/).

**To run:** `racket -t main.rkt -m example.rkt`

**To test:** `raco test interp.rkt`
